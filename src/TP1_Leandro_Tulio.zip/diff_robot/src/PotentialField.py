#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist, Pose, TransformStamped
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan
import tf
import math
from tf2_ros import TransformBroadcaster
import tf2_ros
import geometry_msgs.msg
import tf_conversions

class PotentialField:
    def __init__(self):
        rospy.init_node('potential_field')

        self.stopping_radius = 1  # Radius within which the robot should stop
        self.v_max = 1.0
        self.v_min = 0.5
        self.dgoal_limit = 2
        self.alpha = 1
        self.Qi = 2
        self.n = 1
        self.pub = rospy.Publisher('set_vel', Twist, queue_size=10)
        self.odom_sub = rospy.Subscriber('/odom', Odometry, self.odom_callback)
        self.endpoint_sub = rospy.Subscriber('set_endpoint', Pose, self.endpoint_callback)
        self.scan_sub = rospy.Subscriber('/scan', LaserScan, self.scan_callback)
        self.br = TransformBroadcaster()

        self.current_pose = Pose()
        self.goal_pose = Pose()
        self.goal_reached = False  # Flag to track whether the goal has been reached
        self.rate = rospy.Rate(10)  # Hz

        # Initialize vector components for fields
        self.Uatt_dx = 0
        self.Uatt_dy = 0
        self.Urep_x = 0
        self.Urep_y = 0

    def odom_callback(self, msg):
        self.current_pose = msg.pose.pose

    def endpoint_callback(self, msg):
        self.goal_pose = msg
        self.goal_reached = False  # Reset the goal reached flag when a new goal is set
        self.control_loop()

    def scan_callback(self, msg):
        self.scan_ranges = msg.ranges  # Store distance data from scans
        obstacles = []
        scan_ranges = [r if r != float('inf') else msg.range_max for r in self.scan_ranges]
        threshold_percent = 0.05

        tracking_obstacle = False
        min_value = float('inf')
        min_index = 0

        for i in range(len(scan_ranges) - 1):
            current_range = scan_ranges[i]
            next_range = scan_ranges[i + 1]
            difference = abs(next_range - current_range)

            if difference > threshold_percent * min(current_range, next_range):
                if tracking_obstacle:
                    obstacles.append((min_index, min_value))
                    min_value = float('inf')
                    tracking_obstacle = False
                tracking_obstacle = True
            if tracking_obstacle and min_value > next_range:
                min_value = next_range
                min_index = i + 1
        if tracking_obstacle:
            obstacles.append((min_index, min_value))
            

        self.obstacles = obstacles
        print('obstacles =', self.obstacles)



    def publish_arrow(self, x, y, theta):
        t = geometry_msgs.msg.TransformStamped()
        t.header.stamp = rospy.Time.now()
        t.header.frame_id = "laser_frame"  # Frame pai da seta
        t.child_frame_id = "arrow_link"  # Frame da seta
        t.transform.translation.x = 5  # Coordenadas consistentes com a definição no URDF
        t.transform.translation.y = 0
        t.transform.translation.z = 5  # Corrigido para 0.2 conforme especificado no URDF

        # Criação do quaternion a partir do ângulo theta
        q = tf.transformations.quaternion_from_euler(0, 0, theta)
        t.transform.rotation.x = q[0]
        t.transform.rotation.y = q[1]
        t.transform.rotation.z = q[2]
        t.transform.rotation.w = q[3]

        # Envio da transformação sem loop e sem reinicializar o nó
        self.br.sendTransform(t)

    def repulsive_field(self):
        self.Urep_x = 0
        self.Urep_y = 0
        orientation = self.current_pose.orientation
        quaternion = (orientation.x, orientation.y, orientation.z, orientation.w)
        euler = tf.transformations.euler_from_quaternion(quaternion)
        yaw = euler[2]  # Yaw is the third element (roll, pitch, yaw)
        for index, distance in self.obstacles:
            if distance < self.Qi:
                beta = ((index / 360) *2* math.pi) - math.pi
                #print('beta =',beta)
                #print('yaw =',yaw)
                beta = self.normalize_angle(yaw+beta)
                print('beta2 =',beta)
                Urep = 0.5 * self.n * ((1/distance - 1/self.Qi)**2)
                self.Urep_x -= Urep * math.cos(beta)
                self.Urep_y -= Urep * math.sin(beta)

    def attractive_field(self):
        current_x = self.current_pose.position.x
        current_y = self.current_pose.position.y
        goal_x = self.goal_pose.position.x
        goal_y = self.goal_pose.position.y

        dgoal = math.sqrt((goal_x - current_x)**2 + (goal_y - current_y)**2)
        if dgoal < self.stopping_radius:
            self.Uatt_dx = 0
            self.Uatt_dy = 0
        elif dgoal < self.dgoal_limit:
            self.Uatt_dx = self.alpha * (goal_x - current_x)
            self.Uatt_dy = self.alpha * (goal_y - current_y)
        else:
            goal_theta = self.normalize_angle(math.atan2(goal_y - current_y, goal_x - current_x))
            self.publish_arrow(current_x, current_y, goal_theta)
            self.Uatt_dx = self.dgoal_limit * self.alpha * math.cos(goal_theta)
            self.Uatt_dy = self.dgoal_limit * self.alpha * math.sin(goal_theta)


        

    def control_loop(self):
        while not rospy.is_shutdown():
            self.attractive_field()
            self.repulsive_field()
            self.potential_field()
            self.rate.sleep()

    def potential_field(self):
        orientation = self.current_pose.orientation
        quaternion = (orientation.x, orientation.y, orientation.z, orientation.w)
        euler = tf.transformations.euler_from_quaternion(quaternion)
        yaw = euler[2]  # Yaw is the third element (roll, pitch, yaw)

        x_goal = self.Uatt_dx + self.Urep_x
        y_goal = self.Uatt_dy + self.Urep_y
        angle = math.atan2(y_goal, x_goal)
        angle_rep = math.atan2(self.Urep_y, self.Urep_x)


        velocity_command = Twist()
        linear_speed = math.sqrt(x_goal**2 + y_goal**2)
        angle_difference = self.normalize_angle(angle - yaw)
        if abs(angle_difference) > math.pi/2: 
            linear_speed = -linear_speed
        #print('yaw =',yaw)
        
        if linear_speed>0:
            linear_speed = min(linear_speed, self.v_max)
        else:
            linear_speed = max(linear_speed, -self.v_max)


        velocity_command.linear.x = linear_speed
        #velocity_command.linear.x = 0
         # Calculate the shortest angle difference and adjust sign if needed
        
        velocity_command.angular.z = angle_difference
        #velocity_command.angular.z = -1
        self.pub.publish(velocity_command)
        #rospy.loginfo(f"Publishing velocity command: Linear X: {velocity_command.linear.x}, Angular Z: {angle_rep}")

    def normalize_angle(self, angle):
        while angle > math.pi:
            angle -= 2 * math.pi
        while angle < -math.pi:
            angle += 2 * math.pi
        return angle

if __name__ == '__main__':
    try:
        pf = PotentialField()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
            

            

    
