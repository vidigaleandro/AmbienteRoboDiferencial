#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Pose, Quaternion
from nav_msgs.msg import Odometry
import tf
import math
import numpy as np

class Hypotrochoid:
    def __init__(self, steps=50):
        #rospy.loginfo("Initializing Hypotrochoid with steps: {}".format(steps))
        self.points = []
        self.steps = steps
        self.calculate_curve()

    def calculate_curve(self):
        rospy.loginfo("Calculating Hypotrochoid curve")
        for t in np.linspace(0, 6 * math.pi, self.steps):
            x = 2 * math.cos(t) + 5 * math.cos(2 * t / 3)
            y = 2 * math.sin(t) - 5 * math.sin(2 * t / 3)
            self.points.append((x, y))
        #rospy.loginfo("Curve calculated with {} points".format(len(self.points)))

    def get_orientation(self, current_point, next_point):
        dx = next_point[0] - current_point[0]
        dy = next_point[1] - current_point[1]
        angle = math.atan2(dy, dx)
        quaternion = tf.transformations.quaternion_from_euler(0, 0, angle)
        #rospy.loginfo("Calculated orientation from points: {}".format(quaternion))
        return quaternion

class EndpointPublisher:
    def __init__(self):
        rospy.init_node('endpoint_publisher')
        self.pub = rospy.Publisher('set_endpoint', Pose, queue_size=10)
        self.sub = rospy.Subscriber('/odom', Odometry, self.odom_callback)
        self.rate = rospy.Rate(10)  # 10 Hz
        self.hypotrochoid = Hypotrochoid()
        self.current_index = 0
        rospy.loginfo("EndpointPublisher initialized")
        self.publish_next_endpoint()  # Immediately publish the first endpoint

    def odom_callback(self, data):
        current_position = data.pose.pose.position
        self.check_and_update_endpoint(current_position)

    def check_and_update_endpoint(self, current_position):
        if self.current_index < len(self.hypotrochoid.points):
            endpoint = self.hypotrochoid.points[self.current_index]
            self.publish_next_endpoint() 
            if self.distance(current_position, endpoint) < .5:
                #rospy.loginfo("Reached endpoint {}".format(self.current_index))
                self.current_index = (self.current_index + 1) % len(self.hypotrochoid.points)
                self.publish_next_endpoint()
        else:
            self.current_index = 0

    def distance(self, current_position, endpoint):
        return math.sqrt((current_position.x - endpoint[0])**2 + (current_position.y - endpoint[1])**2)

    def publish_next_endpoint(self):
        if self.current_index < len(self.hypotrochoid.points):
            next_point = self.hypotrochoid.points[self.current_index]
            pose = Pose()
            pose.position.x = next_point[0]
            pose.position.y = next_point[1]
            pose.position.z = 0  # Assuming 2D navigation
            quaternion = self.hypotrochoid.get_orientation(self.hypotrochoid.points[max(0, self.current_index - 1)], next_point)
            pose.orientation = Quaternion(*quaternion)
            rospy.loginfo("Publishing new endpoint: ({}, {})".format(pose.position.x, pose.position.y))
            self.pub.publish(pose)

    def run(self):
        rospy.loginfo("Endpoint Publisher is running...")
        while not rospy.is_shutdown():
            self.rate.sleep()

if __name__ == '__main__':
    try:
        publisher = EndpointPublisher()
        publisher.run()
    except rospy.ROSInterruptException:
        pass
